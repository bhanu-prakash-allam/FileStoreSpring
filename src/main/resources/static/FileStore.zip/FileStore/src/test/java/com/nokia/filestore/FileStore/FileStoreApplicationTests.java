package com.nokia.filestore.FileStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
